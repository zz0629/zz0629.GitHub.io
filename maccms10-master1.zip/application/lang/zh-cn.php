<?php
return [
    'hello'  => '欢迎使用苹果CMS-v10',

    'open'=>'开启',
    'close'=>'关闭',
    'task'=>'任务',
    'status'=>'状态',
    'run'=>'执行',
    'skip'=>'跳过',
    'last_run_time'=>'上次执行时间',

    'save_err'=>'文件写入失，请重试!',
    'save_err_config'=>'配置文件写入失，请重试!',
    'save_err_database'=>'数据库配置写入失败，请重试!',


    'api/auth_no'=>'域名未授权',
    'api/close'=>'接口关闭err',
    'api/pass_no'=>'非法使用err',
    'api/require_name'=>'名称必须err',
    'api/require_type'=>'分类名称和分类id至少填写1项err',
    'api/require_sex'=>'性别必须err',
    'api/require_actor'=>'演员名必须err',
    'api/require_role_name'=>'角色名必须err',
    'api/require_vod_name'=>'视频名必须err',





];